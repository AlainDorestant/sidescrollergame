This game is horror themed game with three mechaninc
    1. Hitting a zombie makes it "stick" to the player untill the player clicks it oncet. if it is able to        stick to the player for more than 10secs then the game is over
    2. Hitting an orb increase the availble "ammo" fire. If this is at 0 the player needs to collect more orbs
    3. Hitting a "blob monster" causes a green goo to partiially obsuecre player view for 5seconds
    3. Hitting a "ray gun" give the player the ability to shoot away zombies

    you win by killing 10 zombies

    you lose by when hp goes to zero this can happen in two ways
        1. you let a zombie stick to you for 10 5seconds
        2. you hit too many "blob monsters"



Borrowed assets URLs

Background image
    -https://www.google.com/search?q=zombie+abckground&oq=zombie+abckground&gs_lcrp=EgZjaHJvbWUyBggAEEUYOTIJCAEQABgNGIAEMgkIAhAAGA0YgAQyCQgDEAAYDRiABDIJCAQQABgNGIAEMgkIBRAAGA0YgAQyCQgGEAAYDRiABDIJCAcQABgNGIAEMgkICBAAGA0YgAQyCQgJEAAYDRiABNIBCDgwODBqMGo3qAIAsAIA&sourceid=chrome&ie=UTF-8#vhid=cCCgJV6REAafkM&vssid=_kWsUaJqSN5Sq5NoP1O3fmAs_48

Orbs
    -https://www.google.com/search?q=orb+custler+png+blue&oq=orb&gs_lcrp=EgZjaHJvbWUqBggAEEUYOzIGCAAQRRg7Mg8IARBFGDkYgwEYsQMYgAQyEAgCEC4YxwEYsQMY0QMYgAQyBggDEEUYOzIGCAQQRRg7MhAIBRAuGMcBGLEDGNEDGIAEMgYIBhBFGD0yBggHEEUYPNIBCDIxMDlqMGo3qAIAsAIA&sourceid=chrome&ie=UTF-8#vhid=Ah9xiAbrjSD5XM&vssid=_tmsUaK_SOMGr5NoP7a3RqQE_38

bullets/rays
   -https://www.google.com/search?q=ammo+png+videogames+wenrexa&sca_esv=599b8d6373705053&udm=2&biw=1920&bih=1033&sxsrf=AHTn8zowEoRNbjpZ6SRESzPpIwW8QxRHvQ%3A1746168833179&ei=AWwUaNrbCvyg5NoPo7Te6QM&ved=0ahUKEwia4JPomYSNAxV8EFkFHSOaNz0Q4dUDCBE&uact=5&oq=ammo+png+videogames+wenrexa&gs_lp=EgNpbWciG2FtbW8gcG5nIHZpZGVvZ2FtZXMgd2VucmV4YUjwE1DrA1iBE3ABeACQAQCYATegAaIDqgEBOLgBA8gBAPgBAZgCAKACAJgDAIgGAZIHAKAH6AKyBwC4BwA&sclient=img#vhid=DqVD5ZCcyqgWdM&vssid=mosaic

Gun
   -https://www.google.com/search?source=lns.web.gsbubb&vsdim=1000,714&gsessionid=puthXcqjD4AYY7Hnfwie0qHNT9OqaxmAdt8fjLMkbaoQ4ZipMJ79YQ&lsessionid=xtk3QDwXN0WQpeeYvE3zcFimdlvKH250UP2vWguxEDrvciwhqU5BTQ&lns_surface=26&biw=1920&bih=1033&hl=en&vsrid=CNSfqau614WhRRAEGAEiJEI0RkM3NDE0LTc5QzQtNDAyQi1CQTE1LTU0REExMDVDMjBDMQ&udm=26&q&vsint=CAQqCgoCCAcSAggSIAE6IwoWDef76T4VtOUAPx32KNw-JSrjBz8wARDoBxjKBSUAAIA_&lns_mode=un&qsubts=1746168920438&stq=1&cs=1&lei=U2wUaNmYDNvJwN4Pt5Xx4Qw#vhid=sYXYDAGy4OmJ0M&vssid=mosaic

Plyaer model
  - https://www.google.com/search?source=lns.web.gsbubb&vsdim=314,376&gsessionid=Cu4RVErh7aqZy9Xo7R97WKaKUpIvJw7qi5oQ9WWRon-Bn131Axd6Vw&lsessionid=crcjkUQo7EcH-KmlY5xw-OZah3QOSeaq0ida9uryreA_DoR0Wj7PdA&lns_surface=26&biw=1920&bih=1033&hl=en&vsrid=COuPyejVjc2_aBAEGAEiJDA4NjcwRDRGLTA1N0MtNDkzMy04QjZELTJFQkY3QjBCQzMwMg&udm=26&q&vsint=CAQqCgoCCAcSAggSIAE6IwoWDTKPCD8VX5j8Ph0uylQ_Jbg7ez8wARC6Ahj4AiUAAIA_&lns_mode=un&qsubts=1746168962486&stq=1&cs=1&lei=f2wUaPO4Ddf-p84Pmd3aqQw#vhid=o2Udk336yr8IsM&vssid=mosaic

Goo overlay
 -https://www.google.com/search?source=lns.web.gsbubb&vsdim=612,445&gsessionid=KDIDcYAcObSJK2Da0HPVxFValgxQz-lVX2_nZFogFyTivkUyJoF8DA&lsessionid=7yYetdXZIKLEeGruBASHp_8hHcJu5BIgXnBT8-f3BetG60jsj-paBA&lns_surface=26&biw=1920&bih=1033&hl=en&vsrid=CP6QzYnz8afUKxAEGAEiJDQ1NEYwMUFELUY2NzItNDRGRC1CNjBELTE4QjA5RjI2NUU5RQ&udm=26&q&vsint=CAQqCgoCCAcSAggSIAE6IwoWDZq2Cz8VADpMPx0pBQU_JeaupT4wARDkBBi9AyUAAIA_&lns_mode=un&qsubts=1746169024833&stq=1&cs=1&lei=vGwUaO_VM66_p84PotvyoAc#vhid=uLgHMOYOP8xnSM&vssid=mosaic


 Splash Screen
        https://www.slidescarnival.com/template/zombie-day-minitheme/59203







